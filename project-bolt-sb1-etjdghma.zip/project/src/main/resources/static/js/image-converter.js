let currentJobId = null;
let currentData = { headers: [], data: [] };

const uploadArea = document.getElementById('uploadArea');
const fileInput = document.getElementById('fileInput');
const uploadBtn = document.getElementById('uploadBtn');
const resultSection = document.getElementById('resultSection');
const userId = '00000000-0000-0000-0000-000000000000';

uploadArea.addEventListener('click', () => fileInput.click());

uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.classList.add('drag-over');
});

uploadArea.addEventListener('dragleave', () => {
    uploadArea.classList.remove('drag-over');
});

uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.classList.remove('drag-over');
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        fileInput.files = files;
        uploadBtn.style.display = 'block';
    }
});

fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
        uploadBtn.style.display = 'block';
    }
});

uploadBtn.addEventListener('click', async () => {
    const file = fileInput.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);
    formData.append('userId', userId);

    uploadBtn.disabled = true;
    uploadBtn.textContent = 'Processing...';

    try {
        const response = await fetch('/api/image-converter/upload', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (result.status === 'COMPLETED') {
            currentJobId = result.jobId;
            currentData = { headers: result.headers, data: result.data };
            displayData(result);
            showNotification('Image processed successfully!');
        } else {
            showNotification('Error: ' + result.message, 'error');
        }
    } catch (error) {
        showNotification('Error uploading file: ' + error.message, 'error');
    } finally {
        uploadBtn.disabled = false;
        uploadBtn.textContent = 'Process Image';
    }
});

function displayData(result) {
    resultSection.style.display = 'block';

    document.getElementById('rowCount').textContent = `${result.rowCount} rows`;
    document.getElementById('columnCount').textContent = `${result.headers.length} columns`;

    const tableHeader = document.getElementById('tableHeader');
    tableHeader.innerHTML = '';
    const headerRow = document.createElement('tr');
    result.headers.forEach(header => {
        const th = document.createElement('th');
        th.textContent = header;
        headerRow.appendChild(th);
    });
    tableHeader.appendChild(headerRow);

    const tableBody = document.getElementById('tableBody');
    tableBody.innerHTML = '';
    result.data.forEach(row => {
        const tr = document.createElement('tr');
        result.headers.forEach(header => {
            const td = document.createElement('td');
            td.textContent = row[header] || '';
            tr.appendChild(td);
        });
        tableBody.appendChild(tr);
    });

    updateColumnSelectors(result.headers);
}

function updateColumnSelectors(headers) {
    const selectors = ['filterColumn', 'sortColumn', 'renameOldName', 'removeColumn'];
    selectors.forEach(selectorId => {
        const select = document.getElementById(selectorId);
        if (select) {
            select.innerHTML = '<option value="">Select column...</option>';
            headers.forEach(header => {
                const option = document.createElement('option');
                option.value = header;
                option.textContent = header;
                select.appendChild(option);
            });
        }
    });
}

document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;

        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

        btn.classList.add('active');
        document.getElementById(tab).classList.add('active');
    });
});

document.getElementById('transformationType').addEventListener('change', (e) => {
    document.querySelectorAll('.transformation-options').forEach(opt => {
        opt.style.display = 'none';
    });

    const type = e.target.value;
    if (type === 'FILTER') {
        document.getElementById('filterOptions').style.display = 'block';
    } else if (type === 'SORT') {
        document.getElementById('sortOptions').style.display = 'block';
    } else if (type === 'RENAME_COLUMN') {
        document.getElementById('renameOptions').style.display = 'block';
    } else if (type === 'REMOVE_COLUMN') {
        document.getElementById('removeOptions').style.display = 'block';
    } else if (type === 'ADD_COLUMN') {
        document.getElementById('addOptions').style.display = 'block';
    }
});

document.getElementById('applyTransformationBtn').addEventListener('click', async () => {
    if (!currentJobId) {
        showNotification('Please upload and process a file first', 'error');
        return;
    }

    const type = document.getElementById('transformationType').value;
    if (!type) {
        showNotification('Please select a transformation type', 'error');
        return;
    }

    let config = {};

    if (type === 'FILTER') {
        config = {
            column: document.getElementById('filterColumn').value,
            operator: document.getElementById('filterOperator').value,
            value: document.getElementById('filterValue').value
        };
    } else if (type === 'SORT') {
        config = {
            column: document.getElementById('sortColumn').value,
            order: document.getElementById('sortOrder').value
        };
    } else if (type === 'RENAME_COLUMN') {
        config = {
            oldName: document.getElementById('renameOldName').value,
            newName: document.getElementById('renameNewName').value
        };
    } else if (type === 'REMOVE_COLUMN') {
        config = {
            columnName: document.getElementById('removeColumn').value
        };
    } else if (type === 'ADD_COLUMN') {
        config = {
            columnName: document.getElementById('addColumnName').value,
            defaultValue: document.getElementById('addDefaultValue').value
        };
    }

    try {
        const response = await fetch('/api/transformation/apply', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                jobId: currentJobId,
                transformationType: type,
                config: config
            })
        });

        const result = await response.json();

        if (result.headers && result.data) {
            currentData = { headers: result.headers, data: result.data };
            displayData({
                headers: result.headers,
                data: result.data,
                rowCount: result.rowCount
            });
            showNotification('Transformation applied successfully!');
            loadTransformationHistory();
        } else {
            showNotification('Error: ' + (result.error || 'Unknown error'), 'error');
        }
    } catch (error) {
        showNotification('Error applying transformation: ' + error.message, 'error');
    }
});

async function loadTransformationHistory() {
    if (!currentJobId) return;

    try {
        const response = await fetch(`/api/transformation/history/${currentJobId}`);
        const history = await response.json();

        const historyList = document.getElementById('historyList');
        historyList.innerHTML = '';

        if (history.length === 0) {
            historyList.innerHTML = '<p>No transformations applied yet.</p>';
            return;
        }

        history.forEach((item, index) => {
            const div = document.createElement('div');
            div.className = 'history-item';
            div.innerHTML = `
                <strong>${index + 1}. ${item.transformationType}</strong>
                <p>${formatTransformationConfig(item.transformationType, item.transformationConfig)}</p>
                <small>${new Date(item.appliedAt).toLocaleString()}</small>
            `;
            historyList.appendChild(div);
        });
    } catch (error) {
        console.error('Error loading history:', error);
    }
}

function formatTransformationConfig(type, configString) {
    try {
        const config = JSON.parse(configString);
        if (type === 'FILTER') {
            return `Filter ${config.column} ${config.operator} "${config.value}"`;
        } else if (type === 'SORT') {
            return `Sort by ${config.column} (${config.order})`;
        } else if (type === 'RENAME_COLUMN') {
            return `Rename "${config.oldName}" to "${config.newName}"`;
        } else if (type === 'REMOVE_COLUMN') {
            return `Remove column "${config.columnName}"`;
        } else if (type === 'ADD_COLUMN') {
            return `Add column "${config.columnName}" with default "${config.defaultValue}"`;
        }
    } catch (e) {
        return 'Configuration: ' + configString;
    }
}

document.getElementById('exportCsvBtn').addEventListener('click', async () => {
    if (!currentJobId) {
        showNotification('Please upload and process a file first', 'error');
        return;
    }

    try {
        window.location.href = `/api/export/${currentJobId}/csv`;
        showNotification('Exporting to CSV...');
    } catch (error) {
        showNotification('Error exporting to CSV: ' + error.message, 'error');
    }
});

document.getElementById('exportExcelBtn').addEventListener('click', async () => {
    if (!currentJobId) {
        showNotification('Please upload and process a file first', 'error');
        return;
    }

    try {
        window.location.href = `/api/export/${currentJobId}/excel`;
        showNotification('Exporting to Excel...');
    } catch (error) {
        showNotification('Error exporting to Excel: ' + error.message, 'error');
    }
});

document.getElementById('exportJsonBtn').addEventListener('click', async () => {
    if (!currentJobId) {
        showNotification('Please upload and process a file first', 'error');
        return;
    }

    try {
        const response = await fetch('/api/export/json', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ jobId: currentJobId })
        });

        const json = await response.text();
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `export_${currentJobId}.json`;
        a.click();
        URL.revokeObjectURL(url);

        showNotification('Exported to JSON successfully!');
    } catch (error) {
        showNotification('Error exporting to JSON: ' + error.message, 'error');
    }
});

function showNotification(message, type = 'success') {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.className = 'notification ' + (type === 'error' ? 'error' : '');
    notification.classList.add('show');

    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}
