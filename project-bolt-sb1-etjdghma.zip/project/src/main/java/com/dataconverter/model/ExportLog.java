package com.dataconverter.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Entity
@Table(name = "export_logs")
public class ExportLog {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "job_id", nullable = false)
    private UUID jobId;

    @Column(name = "export_format", nullable = false)
    private String exportFormat;

    @Column(nullable = false)
    private String destination;

    @Column(name = "exported_at")
    private LocalDateTime exportedAt = LocalDateTime.now();

    @Column(nullable = false)
    private String status = "SUCCESS";
}
