package com.dataconverter.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Entity
@Table(name = "transformations")
public class Transformation {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "job_id", nullable = false)
    private UUID jobId;

    @Column(name = "transformation_type", nullable = false)
    private String transformationType;

    @Column(name = "transformation_config", columnDefinition = "jsonb")
    private String transformationConfig;

    @Column(name = "applied_at")
    private LocalDateTime appliedAt = LocalDateTime.now();
}
