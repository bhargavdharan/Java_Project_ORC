package com.dataconverter.model;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.Type;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Entity
@Table(name = "extracted_data")
public class ExtractedData {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "job_id", nullable = false)
    private UUID jobId;

    @Column(columnDefinition = "jsonb")
    private String headers;

    @Column(name = "data_rows", columnDefinition = "jsonb")
    private String dataRows;

    @Column(name = "row_count")
    private Integer rowCount = 0;

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();
}
