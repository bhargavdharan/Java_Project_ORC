package com.dataconverter.service;

import com.dataconverter.model.ExportLog;
import com.dataconverter.model.ExtractedData;
import com.dataconverter.repository.ExportLogRepository;
import com.dataconverter.repository.ExtractedDataRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opencsv.CSVWriter;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ExportService {

    private final ExtractedDataRepository extractedDataRepository;
    private final ExportLogRepository exportLogRepository;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public File exportToCSV(UUID jobId) throws Exception {
        ExtractedData extractedData = extractedDataRepository.findByJobId(jobId)
                .orElseThrow(() -> new RuntimeException("No data found for job"));

        List<String> headers = objectMapper.readValue(extractedData.getHeaders(), new TypeReference<>() {});
        List<Map<String, String>> data = objectMapper.readValue(extractedData.getDataRows(), new TypeReference<>() {});

        File csvFile = File.createTempFile("export_" + jobId, ".csv");

        try (CSVWriter writer = new CSVWriter(new FileWriter(csvFile))) {
            writer.writeNext(headers.toArray(new String[0]));

            for (Map<String, String> row : data) {
                String[] rowData = new String[headers.size()];
                for (int i = 0; i < headers.size(); i++) {
                    rowData[i] = row.getOrDefault(headers.get(i), "");
                }
                writer.writeNext(rowData);
            }
        }

        logExport(jobId, "CSV", csvFile.getAbsolutePath());
        return csvFile;
    }

    public File exportToExcel(UUID jobId) throws Exception {
        ExtractedData extractedData = extractedDataRepository.findByJobId(jobId)
                .orElseThrow(() -> new RuntimeException("No data found for job"));

        List<String> headers = objectMapper.readValue(extractedData.getHeaders(), new TypeReference<>() {});
        List<Map<String, String>> data = objectMapper.readValue(extractedData.getDataRows(), new TypeReference<>() {});

        File excelFile = File.createTempFile("export_" + jobId, ".xlsx");

        try (Workbook workbook = new XSSFWorkbook(); FileOutputStream fos = new FileOutputStream(excelFile)) {
            Sheet sheet = workbook.createSheet("Data");

            Row headerRow = sheet.createRow(0);
            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);

            for (int i = 0; i < headers.size(); i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers.get(i));
                cell.setCellStyle(headerStyle);
            }

            int rowNum = 1;
            for (Map<String, String> rowData : data) {
                Row row = sheet.createRow(rowNum++);
                for (int i = 0; i < headers.size(); i++) {
                    Cell cell = row.createCell(i);
                    cell.setCellValue(rowData.getOrDefault(headers.get(i), ""));
                }
            }

            for (int i = 0; i < headers.size(); i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(fos);
        }

        logExport(jobId, "EXCEL", excelFile.getAbsolutePath());
        return excelFile;
    }

    public String exportToJSON(UUID jobId) throws Exception {
        ExtractedData extractedData = extractedDataRepository.findByJobId(jobId)
                .orElseThrow(() -> new RuntimeException("No data found for job"));

        List<String> headers = objectMapper.readValue(extractedData.getHeaders(), new TypeReference<>() {});
        List<Map<String, String>> data = objectMapper.readValue(extractedData.getDataRows(), new TypeReference<>() {});

        Map<String, Object> exportData = Map.of(
                "headers", headers,
                "data", data,
                "rowCount", data.size()
        );

        String json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(exportData);
        logExport(jobId, "JSON", "inline");
        return json;
    }

    private void logExport(UUID jobId, String format, String destination) {
        ExportLog log = new ExportLog();
        log.setJobId(jobId);
        log.setExportFormat(format);
        log.setDestination(destination);
        log.setStatus("SUCCESS");
        exportLogRepository.save(log);
    }
}
