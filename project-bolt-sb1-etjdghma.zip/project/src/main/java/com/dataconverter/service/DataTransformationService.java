package com.dataconverter.service;

import com.dataconverter.model.ExtractedData;
import com.dataconverter.model.Transformation;
import com.dataconverter.repository.ExtractedDataRepository;
import com.dataconverter.repository.TransformationRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DataTransformationService {

    private final ExtractedDataRepository extractedDataRepository;
    private final TransformationRepository transformationRepository;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public Map<String, Object> applyTransformation(UUID jobId, String transformationType, Map<String, Object> config) throws Exception {
        ExtractedData extractedData = extractedDataRepository.findByJobId(jobId)
                .orElseThrow(() -> new RuntimeException("No data found for job"));

        List<String> headers = objectMapper.readValue(extractedData.getHeaders(), new TypeReference<>() {});
        List<Map<String, String>> data = objectMapper.readValue(extractedData.getDataRows(), new TypeReference<>() {});

        Map<String, Object> result = new HashMap<>();

        switch (transformationType.toUpperCase()) {
            case "FILTER":
                data = filterData(data, config);
                break;
            case "SORT":
                data = sortData(data, config);
                break;
            case "RENAME_COLUMN":
                Map<String, Object> renamed = renameColumn(headers, data, config);
                headers = (List<String>) renamed.get("headers");
                data = (List<Map<String, String>>) renamed.get("data");
                break;
            case "REMOVE_COLUMN":
                Map<String, Object> removed = removeColumn(headers, data, config);
                headers = (List<String>) removed.get("headers");
                data = (List<Map<String, String>>) removed.get("data");
                break;
            case "ADD_COLUMN":
                Map<String, Object> added = addColumn(headers, data, config);
                headers = (List<String>) added.get("headers");
                data = (List<Map<String, String>>) added.get("data");
                break;
            default:
                throw new IllegalArgumentException("Unknown transformation type: " + transformationType);
        }

        extractedData.setHeaders(objectMapper.writeValueAsString(headers));
        extractedData.setDataRows(objectMapper.writeValueAsString(data));
        extractedData.setRowCount(data.size());
        extractedDataRepository.save(extractedData);

        Transformation transformation = new Transformation();
        transformation.setJobId(jobId);
        transformation.setTransformationType(transformationType);
        transformation.setTransformationConfig(objectMapper.writeValueAsString(config));
        transformationRepository.save(transformation);

        result.put("headers", headers);
        result.put("data", data);
        result.put("rowCount", data.size());
        return result;
    }

    private List<Map<String, String>> filterData(List<Map<String, String>> data, Map<String, Object> config) {
        String column = (String) config.get("column");
        String operator = (String) config.getOrDefault("operator", "equals");
        String value = (String) config.get("value");

        return data.stream()
                .filter(row -> {
                    String cellValue = row.get(column);
                    if (cellValue == null) return false;

                    switch (operator) {
                        case "equals":
                            return cellValue.equals(value);
                        case "contains":
                            return cellValue.contains(value);
                        case "startsWith":
                            return cellValue.startsWith(value);
                        case "endsWith":
                            return cellValue.endsWith(value);
                        case "notEquals":
                            return !cellValue.equals(value);
                        default:
                            return true;
                    }
                })
                .collect(Collectors.toList());
    }

    private List<Map<String, String>> sortData(List<Map<String, String>> data, Map<String, Object> config) {
        String column = (String) config.get("column");
        String order = (String) config.getOrDefault("order", "asc");

        Comparator<Map<String, String>> comparator = Comparator.comparing(
                row -> row.getOrDefault(column, ""),
                String.CASE_INSENSITIVE_ORDER
        );

        if ("desc".equalsIgnoreCase(order)) {
            comparator = comparator.reversed();
        }

        return data.stream()
                .sorted(comparator)
                .collect(Collectors.toList());
    }

    private Map<String, Object> renameColumn(List<String> headers, List<Map<String, String>> data, Map<String, Object> config) {
        String oldName = (String) config.get("oldName");
        String newName = (String) config.get("newName");

        List<String> newHeaders = headers.stream()
                .map(h -> h.equals(oldName) ? newName : h)
                .collect(Collectors.toList());

        List<Map<String, String>> newData = data.stream()
                .map(row -> {
                    Map<String, String> newRow = new HashMap<>();
                    row.forEach((key, value) -> {
                        String newKey = key.equals(oldName) ? newName : key;
                        newRow.put(newKey, value);
                    });
                    return newRow;
                })
                .collect(Collectors.toList());

        Map<String, Object> result = new HashMap<>();
        result.put("headers", newHeaders);
        result.put("data", newData);
        return result;
    }

    private Map<String, Object> removeColumn(List<String> headers, List<Map<String, String>> data, Map<String, Object> config) {
        String columnName = (String) config.get("columnName");

        List<String> newHeaders = headers.stream()
                .filter(h -> !h.equals(columnName))
                .collect(Collectors.toList());

        List<Map<String, String>> newData = data.stream()
                .map(row -> {
                    Map<String, String> newRow = new HashMap<>(row);
                    newRow.remove(columnName);
                    return newRow;
                })
                .collect(Collectors.toList());

        Map<String, Object> result = new HashMap<>();
        result.put("headers", newHeaders);
        result.put("data", newData);
        return result;
    }

    private Map<String, Object> addColumn(List<String> headers, List<Map<String, String>> data, Map<String, Object> config) {
        String columnName = (String) config.get("columnName");
        String defaultValue = (String) config.getOrDefault("defaultValue", "");

        List<String> newHeaders = new ArrayList<>(headers);
        newHeaders.add(columnName);

        List<Map<String, String>> newData = data.stream()
                .map(row -> {
                    Map<String, String> newRow = new HashMap<>(row);
                    newRow.put(columnName, defaultValue);
                    return newRow;
                })
                .collect(Collectors.toList());

        Map<String, Object> result = new HashMap<>();
        result.put("headers", newHeaders);
        result.put("data", newData);
        return result;
    }

    public List<Transformation> getTransformationHistory(UUID jobId) {
        return transformationRepository.findByJobIdOrderByAppliedAtAsc(jobId);
    }
}
