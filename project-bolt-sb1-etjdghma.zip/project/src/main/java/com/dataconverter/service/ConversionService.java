package com.dataconverter.service;

import com.dataconverter.dto.ConversionResponse;
import com.dataconverter.model.ConversionJob;
import com.dataconverter.model.ExtractedData;
import com.dataconverter.repository.ConversionJobRepository;
import com.dataconverter.repository.ExtractedDataRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class ConversionService {

    private final ConversionJobRepository conversionJobRepository;
    private final ExtractedDataRepository extractedDataRepository;
    private final ImageExtractionService imageExtractionService;
    private final PdfExtractionService pdfExtractionService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    private static final String UPLOAD_DIR = "./uploads";

    public ConversionResponse processImageUpload(MultipartFile file, UUID userId) {
        ConversionJob job = new ConversionJob();
        job.setJobType(ConversionJob.JobType.IMAGE_TO_CSV);
        job.setOriginalFilename(file.getOriginalFilename());
        job.setUserId(userId);
        job.setStatus(ConversionJob.JobStatus.UPLOADED);

        try {
            File savedFile = saveFile(file);
            job.setFilePath(savedFile.getAbsolutePath());
            job = conversionJobRepository.save(job);

            job.setStatus(ConversionJob.JobStatus.PROCESSING);
            job.setUpdatedAt(LocalDateTime.now());
            conversionJobRepository.save(job);

            Map<String, Object> extractedData = imageExtractionService.extractDataFromImage(savedFile);

            saveExtractedData(job.getId(), extractedData);

            job.setStatus(ConversionJob.JobStatus.COMPLETED);
            job.setUpdatedAt(LocalDateTime.now());
            conversionJobRepository.save(job);

            return buildResponse(job.getId(), extractedData);

        } catch (Exception e) {
            job.setStatus(ConversionJob.JobStatus.FAILED);
            job.setErrorMessage(e.getMessage());
            job.setUpdatedAt(LocalDateTime.now());
            conversionJobRepository.save(job);

            ConversionResponse response = new ConversionResponse();
            response.setJobId(job.getId());
            response.setStatus("FAILED");
            response.setMessage("Error processing image: " + e.getMessage());
            return response;
        }
    }

    public ConversionResponse processPdfUpload(MultipartFile file, UUID userId) {
        ConversionJob job = new ConversionJob();
        job.setJobType(ConversionJob.JobType.PDF_TO_CSV);
        job.setOriginalFilename(file.getOriginalFilename());
        job.setUserId(userId);
        job.setStatus(ConversionJob.JobStatus.UPLOADED);

        try {
            File savedFile = saveFile(file);
            job.setFilePath(savedFile.getAbsolutePath());
            job = conversionJobRepository.save(job);

            job.setStatus(ConversionJob.JobStatus.PROCESSING);
            job.setUpdatedAt(LocalDateTime.now());
            conversionJobRepository.save(job);

            Map<String, Object> extractedData = pdfExtractionService.extractDataFromPdf(savedFile);

            saveExtractedData(job.getId(), extractedData);

            job.setStatus(ConversionJob.JobStatus.COMPLETED);
            job.setUpdatedAt(LocalDateTime.now());
            conversionJobRepository.save(job);

            return buildResponse(job.getId(), extractedData);

        } catch (Exception e) {
            job.setStatus(ConversionJob.JobStatus.FAILED);
            job.setErrorMessage(e.getMessage());
            job.setUpdatedAt(LocalDateTime.now());
            conversionJobRepository.save(job);

            ConversionResponse response = new ConversionResponse();
            response.setJobId(job.getId());
            response.setStatus("FAILED");
            response.setMessage("Error processing PDF: " + e.getMessage());
            return response;
        }
    }

    public ConversionResponse getJobData(UUID jobId) throws Exception {
        ConversionJob job = conversionJobRepository.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found"));

        ExtractedData extractedData = extractedDataRepository.findByJobId(jobId)
                .orElseThrow(() -> new RuntimeException("No data found for job"));

        List<String> headers = objectMapper.readValue(extractedData.getHeaders(), List.class);
        List<Map<String, String>> data = objectMapper.readValue(extractedData.getDataRows(), List.class);

        ConversionResponse response = new ConversionResponse();
        response.setJobId(job.getId());
        response.setStatus(job.getStatus().name());
        response.setHeaders(headers);
        response.setData(data);
        response.setRowCount(extractedData.getRowCount());
        response.setMessage("Data retrieved successfully");

        return response;
    }

    public List<ConversionJob> getUserJobs(UUID userId) {
        return conversionJobRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    private File saveFile(MultipartFile file) throws IOException {
        Path uploadPath = Paths.get(UPLOAD_DIR);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        String filename = System.currentTimeMillis() + "_" + file.getOriginalFilename();
        Path filePath = uploadPath.resolve(filename);
        Files.copy(file.getInputStream(), filePath);

        return filePath.toFile();
    }

    private void saveExtractedData(UUID jobId, Map<String, Object> extractedData) throws Exception {
        ExtractedData data = new ExtractedData();
        data.setJobId(jobId);
        data.setHeaders(objectMapper.writeValueAsString(extractedData.get("headers")));
        data.setDataRows(objectMapper.writeValueAsString(extractedData.get("data")));

        List<?> dataList = (List<?>) extractedData.get("data");
        data.setRowCount(dataList.size());

        extractedDataRepository.save(data);
    }

    private ConversionResponse buildResponse(UUID jobId, Map<String, Object> extractedData) {
        ConversionResponse response = new ConversionResponse();
        response.setJobId(jobId);
        response.setStatus("COMPLETED");
        response.setHeaders((List<String>) extractedData.get("headers"));
        response.setData((List<Map<String, String>>) extractedData.get("data"));
        response.setRowCount(((List<?>) extractedData.get("data")).size());
        response.setMessage("File processed successfully");
        return response;
    }
}
