package com.dataconverter.service;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.*;

@Service
public class PdfExtractionService {

    public Map<String, Object> extractDataFromPdf(File pdfFile) throws IOException {
        try (PDDocument document = PDDocument.load(pdfFile)) {
            PDFTextStripper stripper = new PDFTextStripper();
            String text = stripper.getText(document);

            return parseTextToTableData(text);
        }
    }

    private Map<String, Object> parseTextToTableData(String text) {
        Map<String, Object> result = new HashMap<>();
        List<String> headers = new ArrayList<>();
        List<Map<String, String>> rows = new ArrayList<>();

        String[] lines = text.split("\n");
        List<String> nonEmptyLines = new ArrayList<>();

        for (String line : lines) {
            String trimmed = line.trim();
            if (!trimmed.isEmpty()) {
                nonEmptyLines.add(trimmed);
            }
        }

        if (nonEmptyLines.isEmpty()) {
            result.put("headers", Collections.emptyList());
            result.put("data", Collections.emptyList());
            return result;
        }

        String firstLine = nonEmptyLines.get(0);
        String[] headerCandidates = splitByDelimiters(firstLine);
        headers.addAll(Arrays.asList(headerCandidates));

        for (int i = 1; i < nonEmptyLines.size(); i++) {
            String[] values = splitByDelimiters(nonEmptyLines.get(i));
            Map<String, String> row = new HashMap<>();

            for (int j = 0; j < Math.min(headers.size(), values.length); j++) {
                row.put(headers.get(j), values[j]);
            }

            if (!row.isEmpty()) {
                rows.add(row);
            }
        }

        result.put("headers", headers);
        result.put("data", rows);
        return result;
    }

    private String[] splitByDelimiters(String line) {
        if (line.contains("|")) {
            return Arrays.stream(line.split("\\|"))
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .toArray(String[]::new);
        } else if (line.contains("\t")) {
            return line.split("\t");
        } else if (line.contains(",")) {
            return line.split(",");
        } else {
            return line.split("\\s{2,}");
        }
    }
}
