package com.dataconverter.dto;

import lombok.Data;
import java.util.Map;
import java.util.UUID;

@Data
public class TransformationRequest {
    private UUID jobId;
    private String transformationType;
    private Map<String, Object> config;
}
