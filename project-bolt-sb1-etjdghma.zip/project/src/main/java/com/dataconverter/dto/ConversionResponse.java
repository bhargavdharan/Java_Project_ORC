package com.dataconverter.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConversionResponse {
    private UUID jobId;
    private String status;
    private List<String> headers;
    private List<Map<String, String>> data;
    private Integer rowCount;
    private String message;
}
