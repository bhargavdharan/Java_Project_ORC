package com.dataconverter.dto;

import lombok.Data;
import java.util.UUID;

@Data
public class ExportRequest {
    private UUID jobId;
    private String format;
    private String destination;
}
