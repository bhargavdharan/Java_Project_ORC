package com.dataconverter.controller;

import com.dataconverter.dto.TransformationRequest;
import com.dataconverter.model.Transformation;
import com.dataconverter.service.DataTransformationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/transformation")
@RequiredArgsConstructor
public class TransformationController {

    private final DataTransformationService transformationService;

    @PostMapping("/apply")
    public ResponseEntity<?> applyTransformation(@RequestBody TransformationRequest request) {
        try {
            Map<String, Object> result = transformationService.applyTransformation(
                    request.getJobId(),
                    request.getTransformationType(),
                    request.getConfig()
            );
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Error applying transformation: " + e.getMessage()));
        }
    }

    @GetMapping("/history/{jobId}")
    public ResponseEntity<List<Transformation>> getTransformationHistory(@PathVariable UUID jobId) {
        try {
            List<Transformation> history = transformationService.getTransformationHistory(jobId);
            return ResponseEntity.ok(history);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }
}
