package com.dataconverter.controller;

import com.dataconverter.dto.ExportRequest;
import com.dataconverter.service.ExportService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/export")
@RequiredArgsConstructor
public class ExportController {

    private final ExportService exportService;

    @PostMapping("/csv")
    public ResponseEntity<Resource> exportToCSV(@RequestBody ExportRequest request) {
        try {
            File csvFile = exportService.exportToCSV(request.getJobId());
            Resource resource = new FileSystemResource(csvFile);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=export.csv")
                    .contentType(MediaType.parseMediaType("text/csv"))
                    .body(resource);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/excel")
    public ResponseEntity<Resource> exportToExcel(@RequestBody ExportRequest request) {
        try {
            File excelFile = exportService.exportToExcel(request.getJobId());
            Resource resource = new FileSystemResource(excelFile);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=export.xlsx")
                    .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(resource);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/json")
    public ResponseEntity<?> exportToJSON(@RequestBody ExportRequest request) {
        try {
            String json = exportService.exportToJSON(request.getJobId());
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(json);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Error exporting to JSON: " + e.getMessage()));
        }
    }

    @GetMapping("/{jobId}/csv")
    public ResponseEntity<Resource> downloadCSV(@PathVariable UUID jobId) {
        try {
            File csvFile = exportService.exportToCSV(jobId);
            Resource resource = new FileSystemResource(csvFile);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=export_" + jobId + ".csv")
                    .contentType(MediaType.parseMediaType("text/csv"))
                    .body(resource);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/{jobId}/excel")
    public ResponseEntity<Resource> downloadExcel(@PathVariable UUID jobId) {
        try {
            File excelFile = exportService.exportToExcel(jobId);
            Resource resource = new FileSystemResource(excelFile);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=export_" + jobId + ".xlsx")
                    .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(resource);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
