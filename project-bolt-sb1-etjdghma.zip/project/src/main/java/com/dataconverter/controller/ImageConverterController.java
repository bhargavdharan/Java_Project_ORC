package com.dataconverter.controller;

import com.dataconverter.dto.ConversionResponse;
import com.dataconverter.service.ConversionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;

@RestController
@RequestMapping("/api/image-converter")
@RequiredArgsConstructor
public class ImageConverterController {

    private final ConversionService conversionService;

    @PostMapping("/upload")
    public ResponseEntity<ConversionResponse> uploadImage(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "userId", required = false, defaultValue = "00000000-0000-0000-0000-000000000000") String userId) {

        if (file.isEmpty()) {
            ConversionResponse errorResponse = new ConversionResponse();
            errorResponse.setStatus("FAILED");
            errorResponse.setMessage("File is empty");
            return ResponseEntity.badRequest().body(errorResponse);
        }

        try {
            UUID userUuid = UUID.fromString(userId);
            ConversionResponse response = conversionService.processImageUpload(file, userUuid);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            ConversionResponse errorResponse = new ConversionResponse();
            errorResponse.setStatus("FAILED");
            errorResponse.setMessage("Error uploading file: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @GetMapping("/job/{jobId}")
    public ResponseEntity<ConversionResponse> getJobData(@PathVariable UUID jobId) {
        try {
            ConversionResponse response = conversionService.getJobData(jobId);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            ConversionResponse errorResponse = new ConversionResponse();
            errorResponse.setStatus("FAILED");
            errorResponse.setMessage("Error retrieving job data: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }
    }
}
