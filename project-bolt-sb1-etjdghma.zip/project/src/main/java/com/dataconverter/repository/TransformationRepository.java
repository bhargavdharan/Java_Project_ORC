package com.dataconverter.repository;

import com.dataconverter.model.Transformation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.UUID;

@Repository
public interface TransformationRepository extends JpaRepository<Transformation, UUID> {
    List<Transformation> findByJobIdOrderByAppliedAtAsc(UUID jobId);
}
