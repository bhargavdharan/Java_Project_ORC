package com.dataconverter.repository;

import com.dataconverter.model.ConversionJob;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.UUID;

@Repository
public interface ConversionJobRepository extends JpaRepository<ConversionJob, UUID> {
    List<ConversionJob> findByUserIdOrderByCreatedAtDesc(UUID userId);
    List<ConversionJob> findByUserIdAndJobType(UUID userId, ConversionJob.JobType jobType);
}
