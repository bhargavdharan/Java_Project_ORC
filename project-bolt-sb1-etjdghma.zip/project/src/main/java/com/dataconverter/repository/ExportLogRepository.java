package com.dataconverter.repository;

import com.dataconverter.model.ExportLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.UUID;

@Repository
public interface ExportLogRepository extends JpaRepository<ExportLog, UUID> {
    List<ExportLog> findByJobIdOrderByExportedAtDesc(UUID jobId);
}
