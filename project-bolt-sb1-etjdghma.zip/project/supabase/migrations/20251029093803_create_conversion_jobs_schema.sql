/*
  # Data Converter Suite Database Schema

  ## Overview
  Creates the database structure for storing conversion jobs, processing history, and extracted data.

  ## New Tables

  ### 1. `conversion_jobs`
  Stores metadata about each conversion job (both image and PDF conversions)
  - `id` (uuid, primary key) - Unique identifier for the job
  - `job_type` (text) - Type of conversion: 'IMAGE_TO_CSV' or 'PDF_TO_CSV'
  - `original_filename` (text) - Original name of uploaded file
  - `file_path` (text) - Storage path of uploaded file
  - `status` (text) - Job status: 'UPLOADED', 'PROCESSING', 'COMPLETED', 'FAILED'
  - `created_at` (timestamptz) - When the job was created
  - `updated_at` (timestamptz) - Last update timestamp
  - `user_id` (uuid) - Reference to authenticated user
  - `error_message` (text, nullable) - Error details if job failed

  ### 2. `extracted_data`
  Stores the actual extracted and transformed data from conversions
  - `id` (uuid, primary key) - Unique identifier
  - `job_id` (uuid, foreign key) - Reference to conversion_jobs
  - `headers` (jsonb) - Column headers extracted from data
  - `data_rows` (jsonb) - Array of data rows
  - `row_count` (integer) - Number of rows extracted
  - `created_at` (timestamptz) - Creation timestamp

  ### 3. `transformations`
  Tracks transformation operations applied to the data
  - `id` (uuid, primary key) - Unique identifier
  - `job_id` (uuid, foreign key) - Reference to conversion_jobs
  - `transformation_type` (text) - Type: 'FILTER', 'SORT', 'RENAME_COLUMN', etc.
  - `transformation_config` (jsonb) - Configuration details
  - `applied_at` (timestamptz) - When transformation was applied

  ### 4. `export_logs`
  Logs all export/load operations
  - `id` (uuid, primary key) - Unique identifier
  - `job_id` (uuid, foreign key) - Reference to conversion_jobs
  - `export_format` (text) - Format: 'CSV', 'EXCEL', 'JSON'
  - `destination` (text) - Export destination or path
  - `exported_at` (timestamptz) - Export timestamp
  - `status` (text) - Export status: 'SUCCESS', 'FAILED'

  ## Security
  - Enable RLS on all tables
  - Users can only access their own conversion jobs and related data
  - Authenticated users required for all operations

  ## Indexes
  - Created on foreign keys and frequently queried columns for performance
*/

CREATE TABLE IF NOT EXISTS conversion_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_type text NOT NULL CHECK (job_type IN ('IMAGE_TO_CSV', 'PDF_TO_CSV')),
  original_filename text NOT NULL,
  file_path text NOT NULL,
  status text NOT NULL DEFAULT 'UPLOADED' CHECK (status IN ('UPLOADED', 'PROCESSING', 'COMPLETED', 'FAILED')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  user_id uuid NOT NULL,
  error_message text
);

CREATE TABLE IF NOT EXISTS extracted_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES conversion_jobs(id) ON DELETE CASCADE,
  headers jsonb NOT NULL DEFAULT '[]'::jsonb,
  data_rows jsonb NOT NULL DEFAULT '[]'::jsonb,
  row_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS transformations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES conversion_jobs(id) ON DELETE CASCADE,
  transformation_type text NOT NULL,
  transformation_config jsonb NOT NULL DEFAULT '{}'::jsonb,
  applied_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS export_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES conversion_jobs(id) ON DELETE CASCADE,
  export_format text NOT NULL CHECK (export_format IN ('CSV', 'EXCEL', 'JSON')),
  destination text NOT NULL,
  exported_at timestamptz DEFAULT now(),
  status text NOT NULL DEFAULT 'SUCCESS' CHECK (status IN ('SUCCESS', 'FAILED'))
);

CREATE INDEX IF NOT EXISTS idx_conversion_jobs_user_id ON conversion_jobs(user_id);
CREATE INDEX IF NOT EXISTS idx_conversion_jobs_status ON conversion_jobs(status);
CREATE INDEX IF NOT EXISTS idx_extracted_data_job_id ON extracted_data(job_id);
CREATE INDEX IF NOT EXISTS idx_transformations_job_id ON transformations(job_id);
CREATE INDEX IF NOT EXISTS idx_export_logs_job_id ON export_logs(job_id);

ALTER TABLE conversion_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE extracted_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE transformations ENABLE ROW LEVEL SECURITY;
ALTER TABLE export_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own conversion jobs"
  ON conversion_jobs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own conversion jobs"
  ON conversion_jobs FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own conversion jobs"
  ON conversion_jobs FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own conversion jobs"
  ON conversion_jobs FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view own extracted data"
  ON extracted_data FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM conversion_jobs
    WHERE conversion_jobs.id = extracted_data.job_id
    AND conversion_jobs.user_id = auth.uid()
  ));

CREATE POLICY "Users can insert own extracted data"
  ON extracted_data FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM conversion_jobs
    WHERE conversion_jobs.id = extracted_data.job_id
    AND conversion_jobs.user_id = auth.uid()
  ));

CREATE POLICY "Users can update own extracted data"
  ON extracted_data FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM conversion_jobs
    WHERE conversion_jobs.id = extracted_data.job_id
    AND conversion_jobs.user_id = auth.uid()
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM conversion_jobs
    WHERE conversion_jobs.id = extracted_data.job_id
    AND conversion_jobs.user_id = auth.uid()
  ));

CREATE POLICY "Users can delete own extracted data"
  ON extracted_data FOR DELETE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM conversion_jobs
    WHERE conversion_jobs.id = extracted_data.job_id
    AND conversion_jobs.user_id = auth.uid()
  ));

CREATE POLICY "Users can view own transformations"
  ON transformations FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM conversion_jobs
    WHERE conversion_jobs.id = transformations.job_id
    AND conversion_jobs.user_id = auth.uid()
  ));

CREATE POLICY "Users can insert own transformations"
  ON transformations FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM conversion_jobs
    WHERE conversion_jobs.id = transformations.job_id
    AND conversion_jobs.user_id = auth.uid()
  ));

CREATE POLICY "Users can delete own transformations"
  ON transformations FOR DELETE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM conversion_jobs
    WHERE conversion_jobs.id = transformations.job_id
    AND conversion_jobs.user_id = auth.uid()
  ));

CREATE POLICY "Users can view own export logs"
  ON export_logs FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM conversion_jobs
    WHERE conversion_jobs.id = export_logs.job_id
    AND conversion_jobs.user_id = auth.uid()
  ));

CREATE POLICY "Users can insert own export logs"
  ON export_logs FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM conversion_jobs
    WHERE conversion_jobs.id = export_logs.job_id
    AND conversion_jobs.user_id = auth.uid()
  ));
