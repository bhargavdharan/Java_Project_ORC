# Data Converter Suite

A comprehensive Spring Boot web application for converting images and PDFs to CSV/Excel format with advanced data transformation capabilities.

## Features

### Two Powerful Utilities

#### 1. Image to CSV Converter
- Upload images containing tabular data
- OCR-based text extraction using Tesseract
- Automatic table structure detection
- Support for PNG, JPG, JPEG formats (up to 50MB)

#### 2. PDF to CSV Converter
- Extract tabular data from PDF documents
- Intelligent table parsing
- Support for PDF files (up to 50MB)

### Three-Tab Workflow

#### General Tab
- Drag-and-drop file upload
- Instant data extraction and preview
- Real-time table display with row/column counts

#### Transformation Tab
- **Filter Rows**: Apply conditions (equals, contains, starts with, ends with, not equals)
- **Sort Data**: Ascending or descending by any column
- **Rename Column**: Change column headers
- **Remove Column**: Delete unwanted columns
- **Add Column**: Create new columns with default values
- Transformation history tracking

#### Export/Load Tab
- Export to CSV format
- Export to Excel format (.xlsx)
- Export to JSON format
- Instant download functionality

## Technology Stack

- **Backend**: Spring Boot 3.2.0, Java 17
- **Database**: PostgreSQL (Supabase)
- **OCR**: Tesseract 4.x, Tess4j 5.9.0
- **PDF Processing**: Apache PDFBox 3.0.1
- **Excel**: Apache POI 5.2.5
- **CSV**: OpenCSV 5.9
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **ORM**: Spring Data JPA

## Database Schema

### Tables
- **conversion_jobs**: Stores metadata about each conversion
- **extracted_data**: Stores the actual extracted table data
- **transformations**: Tracks all transformation operations
- **export_logs**: Logs all export/load operations

### Features
- Row Level Security (RLS) enabled
- User-based data isolation
- Automatic timestamp tracking
- Foreign key constraints

## Prerequisites

- Java 17 or higher
- Maven 3.6+
- PostgreSQL database (Supabase)
- Tesseract OCR installed (optional for local development)

## Installation

1. Clone the repository
2. Configure database connection in `.env`:
   ```
   SUPABASE_URL=your_supabase_url
   SUPABASE_ANON_KEY=your_anon_key
   SUPABASE_DB_URL=jdbc:postgresql://your_db_url
   ```

3. Build the application:
   ```bash
   mvn clean package
   ```

4. Run the application:
   ```bash
   java -jar target/data-converter-suite-1.0.0.jar
   ```

5. Access the application at `http://localhost:8080`

## API Endpoints

### Image Converter
- `POST /api/image-converter/upload` - Upload and process image
- `GET /api/image-converter/job/{jobId}` - Get job data

### PDF Converter
- `POST /api/pdf-converter/upload` - Upload and process PDF
- `GET /api/pdf-converter/job/{jobId}` - Get job data

### Transformations
- `POST /api/transformation/apply` - Apply transformation
- `GET /api/transformation/history/{jobId}` - Get transformation history

### Export
- `GET /api/export/{jobId}/csv` - Export to CSV
- `GET /api/export/{jobId}/excel` - Export to Excel
- `POST /api/export/json` - Export to JSON

## Usage Guide

1. **Select Utility**: Choose Image or PDF converter from home page
2. **Upload File**: Drag and drop or click to upload your file
3. **Review Data**: Check extracted data in the General tab
4. **Transform**: Apply filters, sorting, or column operations in Transformation tab
5. **Export**: Download your processed data in CSV, Excel, or JSON format

## Transformation Examples

### Filter Example
```json
{
  "column": "Status",
  "operator": "equals",
  "value": "Active"
}
```

### Sort Example
```json
{
  "column": "Date",
  "order": "desc"
}
```

### Rename Column Example
```json
{
  "oldName": "Old_Name",
  "newName": "New Name"
}
```

## Security

- All database operations protected with Row Level Security (RLS)
- Users can only access their own conversion jobs
- File uploads validated and sanitized
- Maximum file size enforced (50MB)

## Project Structure

```
src/
├── main/
│   ├── java/com/dataconverter/
│   │   ├── config/          # Configuration classes
│   │   ├── controller/      # REST controllers
│   │   ├── dto/            # Data Transfer Objects
│   │   ├── model/          # JPA entities
│   │   ├── repository/     # Database repositories
│   │   ├── service/        # Business logic
│   │   └── util/           # Utility classes
│   └── resources/
│       ├── static/         # CSS, JavaScript
│       ├── templates/      # HTML templates
│       └── application.properties
└── test/                   # Unit tests
```

## Contributing

Contributions are welcome! Please follow these steps:
1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## License

This project is licensed under the MIT License.

## Support

For issues and questions, please open an issue on the repository.
